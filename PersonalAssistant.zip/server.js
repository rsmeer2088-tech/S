require('dotenv').config();
const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const bodyParser = require('body-parser');
const { Translate } = require('@google-cloud/translate').v2;
const fs = require('fs');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;

const translate = new Translate({ key: process.env.GOOGLE_API_KEY });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

const upload = multer({ dest: 'uploads/' });

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'test.html'));
});

async function translateText(text, targetLang = 'ar') {
  try {
    const [translation] = await translate.translate(text, targetLang);
    return translation;
  } catch (err) {
    console.error('Google Translate API error:', err);
    return null;
  }
}

app.post('/translate', async (req, res) => {
  const { text, target } = req.body;
  if (!text) return res.status(400).json({ error: 'No text provided' });
  const translated = await translateText(text, target || 'ar');
  res.json({ translated });
});

app.post('/upload', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).send('No file uploaded');
  const filePath = req.file.path;
  const originalName = req.file.originalname;
  let response = { message: 'File uploaded', fileName: originalName };

  if (originalName.endsWith('.zip')) {
    try {
      const zip = new AdmZip(filePath);
      const extractPath = path.join(__dirname, 'uploads', path.parse(originalName).name);
      zip.extractAllTo(extractPath, true);
      response.unzip = `Extracted to ${extractPath}`;
    } catch (err) {
      response.error = 'Error extracting zip';
    }
  }

  res.json(response);
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});